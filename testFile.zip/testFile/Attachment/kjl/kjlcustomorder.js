 {
     "orderId": "201904223130300",
     "storeInfo": {},
     "customInfo": {
         "customerName": "3213",
         "customerTel": "43243",
         "sex": "",
         "detailAddress": "",
         "source": "",
         "sourceRemark": ""
     },
     "hustomInfo": {},
     "signInfo": {},
     "constructInfo": {}
 }